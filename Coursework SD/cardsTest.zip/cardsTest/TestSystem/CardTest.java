package TestSystem;

import org.junit.Test;
import src.Card;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotEquals;
import static org.junit.Assert.assertThrows;

public class CardTest {

    @Test
    public void testCreation() {
        // test if created cards have the correct value
        Card card = new Card(5);
        assertEquals(5, card.getValue());
    }

    @Test
    public void testNegative() {
        // test that cards with negative values cannot be created
        assertThrows(IllegalArgumentException.class, () -> new Card(-1));
    }

    @Test
    public void testEquality() {
        // test that two cards can be equated properly
        Card card1 = new Card(5);
        Card card2 = new Card(5);
        Card card3 = new Card(6);
        assertEquals(card1.getValue(), card2.getValue());
        assertNotEquals(card1.getValue(), card3.getValue());
    }

}