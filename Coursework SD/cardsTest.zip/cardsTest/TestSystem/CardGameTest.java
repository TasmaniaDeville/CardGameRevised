package TestSystem;

import org.junit.*;
import org.junit.rules.TemporaryFolder;
import static org.junit.Assert.*;

import src.CardGame;
import src.Deck;
import src.Player;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import java.lang.reflect.*;

public class CardGameTest {
    @Rule
    public TemporaryFolder tempFolder = new TemporaryFolder();

    private CardGame cardGame;

    @Before
    public void cleanFolder() throws Exception {
        // This deletes all the player files created when flushing the player outputs so the tests are accurate
        // probably could do this better
        File currentDir = new File(".");
        // Iterate through files
        File[] files = currentDir.listFiles();
        assert files != null;
        for (File file : files) {
            System.out.println(file.getName());
            // Check if file ends with .txt and has _
            if (file.getName().toLowerCase().endsWith(".txt") && file.getName().contains("_")) {
                file.delete();
            }
        }
    }

    public List<Deck> getDeckField() throws NoSuchFieldException, IllegalAccessException {
        // use reflections to get decks private attribute
        Field decksField = CardGame.class.getDeclaredField("decks");
        decksField.setAccessible(true);
        return (List<Deck>) decksField.get(cardGame);
    }
    public List<Player> getPlayersField() throws NoSuchFieldException, IllegalAccessException {
        // use reflections to get players private attribute
        Field playersField = CardGame.class.getDeclaredField("players");
        playersField.setAccessible(true);
        return (List<Player>) playersField.get(cardGame);
    }

    public CardGame setUpGame(int playerCount) throws IOException {
        // create temporary folder to hold test data
        File packFile = tempFolder.newFile("pack.txt");

        // Create a list with 4 * playerCount numbers, for now j consecutive
        List<String> numbers = new ArrayList<>();
        for (int i = 1; i <= 8 * playerCount; i++) {
            numbers.add(String.valueOf(i));
        }
        Files.write(packFile.toPath(), numbers);
        return new CardGame(playerCount, packFile.getAbsolutePath());
    }

    @Test
    public void testValidPack() throws Exception {
        // Test to see if a valid pack can be loaded
        // Create valid pack file, 8 * no. players

        File packFile = tempFolder.newFile("pack.txt");
        List<String> numbers = List.of("1", "2", "3", "4", "5", "6", "7", "8");
        Files.write(packFile.toPath(), numbers);
        CardGame game = new CardGame(1, packFile.toString());
        assertNotNull(game);
    }

    @Test
    public void testInvalidPack() throws Exception {
        // Test to see if an invalid pack throws exception
        // Test for pack too small
        File packFile = tempFolder.newFile("pack.txt");
        List<String> numbers = List.of("1", "2", "3"); // Too few cards
        Files.write(packFile.toPath(), numbers);

        assertThrows(IllegalArgumentException.class, () -> new CardGame(1, packFile.toString()));
        // Test edge case of pack empty
        Files.write(packFile.toPath(), " ".getBytes());
        assertThrows(IllegalArgumentException.class, () -> new CardGame(1, packFile.toString()));
    }

    @Test
    public void testNonExistentFile() {
        // Test that cardGame cannot be created if no pack file given
        assertThrows(IOException.class, () -> new CardGame(1, "null.txt"));
    }


    @Test
    public void testValidPackForAllPlayerCounts() throws IOException, NoSuchFieldException, IllegalAccessException {
        // Further test to see if packs can be valid, up to 8 players is just arbitrarily chosen
        for (int playerCount = 1; playerCount <= 8; playerCount++) {
            tempFolder.create();
            cardGame = setUpGame(playerCount);
            // Verify decks and players are created

            List<Deck> decks = getDeckField();
            List<Player> players = getPlayersField();

            assertEquals(playerCount, decks.size());
            assertEquals(playerCount, players.size());
            tempFolder.delete();
        }
    }

    @Test
    public void testDealCards() throws IOException, NoSuchFieldException, IllegalAccessException {
        // Test to see that each player hand is size 4 and each deck size 4
        // again test multiple different configurations of players
        for (int playerCount = 1; playerCount <= 8; playerCount++) {
            tempFolder.create();
            cardGame = setUpGame(playerCount);

            List<Player> players = getPlayersField();
            List<Deck> decks = getDeckField();
            // Verify each player has  cards
            for (Player player : players) {
                assertEquals(4, player.getHand().size());
            }
            // Verify decks have been filled
            for (Deck deck : decks) {
                assertEquals(4,deck.getCurrentDeck().size());
            }
            tempFolder.delete();
        }

    }

    @Test
    public void testInitializePlayers() throws IOException, NoSuchFieldException, IllegalAccessException {
        for (int playerCount = 1; playerCount <= 8; playerCount++) {

            tempFolder.create();
            cardGame = setUpGame(playerCount);
            List<Player> players = getPlayersField();
            List<Deck> decks = getDeckField();
            // Verify correct deck assignment, deck n would be drawdeck for player n and deck n+1 or 1 if you are the "last" player
            for (int i = 0; i < players.size(); i++) {
                Player player = players.get(i);
                Deck expectedDrawDeck = decks.get(i);
                // this bit made us feel clever
                Deck expectedDiscardDeck = decks.get((i + 1) % playerCount);

                // Use reflection to verify private fields
                try {
                    Field drawDeckField = Player.class.getDeclaredField("drawDeck");
                    drawDeckField.setAccessible(true);

                    Field discardDeckField = Player.class.getDeclaredField("discardDeck");
                    discardDeckField.setAccessible(true);

                    assertEquals(expectedDrawDeck, drawDeckField.get(player));
                    assertEquals(expectedDiscardDeck, discardDeckField.get(player));

                } catch (Exception e) {
                    fail(e.getMessage());
                }
                tempFolder.delete();
            }
        }

    }

    @Test
    public void testWriteDecksToFile() throws IOException {
        // Test the writeDecksToFile method - that outputs are written to the text files
        for (int playerCount = 2; playerCount <= 8; playerCount++) {
            tempFolder.create();
            cardGame = setUpGame(playerCount);

            // Use reflection to call private method
            try {
                java.lang.reflect.Method writeDecksToFileMethod = CardGame.class.getDeclaredMethod("writeDecksToFile");
                writeDecksToFileMethod.setAccessible(true);
                writeDecksToFileMethod.invoke(cardGame);

                // Verify output files are created
                for (int i = 1; i <= playerCount; i++) {
                    File deckFile = new File("deck" + i + "_output.txt");
                    assertTrue(deckFile.exists());
                    // Verify file is not empty
                    List<String> lines = Files.readAllLines(Paths.get(deckFile.getPath()));
                    assertFalse(lines.isEmpty());
                    new File("deck" + i + "_output.txt").delete();

                }

            } catch (Exception e) {
                fail(e.getMessage());
            }
            tempFolder.delete();
        }

    }

    @Test
    public void testGameEnds() throws IOException, InterruptedException {
        // Test that, given a winnable deck, all threads will terminate
        for (int playerCount = 2; playerCount <= 8; playerCount++) {
            tempFolder.create();
            File packFile = tempFolder.newFile("pack.txt");
            // fill a deck with half even numbers and half 1s, so that a player can surely win with 4 1s
            List<String> numbers = new ArrayList<>();
            for (int i = 1; i <= playerCount * 8; i++) {
                if (i % 2 == 0) {
                    numbers.add(String.valueOf(i));
                }
                else{
                    numbers.add(String.valueOf(1));
                }
            }

            Files.write(packFile.toPath(), numbers);
            cardGame = new CardGame(playerCount, packFile.toString());

            // Run game
            Thread gameThread = new Thread(() -> {
                try {
                    cardGame.play();
                } catch (Exception e) {
                    fail(e.getMessage());
                }
            });

            gameThread.start();

            // Wait ages longer than any game ought to take
            gameThread.join(50000);

            // Verify game finishes
            assertFalse(gameThread.isAlive());

            // Verify output files are created
            assertTrue( new File("player"+playerCount+"_output.txt").exists());
            assertTrue(new File("deck"+playerCount+"_output.txt").exists());
            // delete output files
            new File("deck"+playerCount+"_output.txt").delete();
            new File("player"+playerCount+"_output.txt").delete();
            tempFolder.delete();
        }

    }

    @After
    public void deleteVariables() throws IOException {
        cardGame = null;
        tempFolder.delete();
        tempFolder.create();

    }





}