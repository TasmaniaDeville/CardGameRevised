package TestSystem;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import src.Card;
import src.Deck;
import src.Player;

import java.io.File;
import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.nio.file.Files;
import java.util.List;
import java.util.concurrent.atomic.AtomicBoolean;
import java.lang.reflect.*;
import java.util.concurrent.atomic.AtomicInteger;

import static org.junit.Assert.*;

public class PlayerTest {
    private Player player;
    private Deck drawDeck;
    private Deck discardDeck;
    private AtomicBoolean gameWon;
    private AtomicInteger winner;

    @Before
    public void setUpTest() throws IOException {
        drawDeck = new Deck(1);
        discardDeck = new Deck(2);
        gameWon = new AtomicBoolean(false);
        winner = new AtomicInteger(0);
        player = new Player(drawDeck, discardDeck, 1, gameWon, winner);
    }

    @Test
    public void testDrawAndDiscard() {
        // check that a player can discard and draw cards and that these methods correctly affect the player's hand
        Card card1 = new Card(1);
        Card card2 = new Card(2);
        player.drawCard(card1);
        player.drawCard(card2);
        assertEquals(2, player.getHand().size());
        assertEquals(card1, player.getHand().getFirst());
        player.discardCard(card1);
        assertEquals(1, player.getHand().size());
        assertEquals(card2, player.getHand().getFirst());
    }

    @Test
    public void testWinningHand() {
        // check if a hand of all 1s causes hasWinningHand() to return true
        for (int i = 0; i < 4; i++) {
            player.drawCard(new Card(1));
        }
        player.hasWinningHand();
        assertTrue(gameWon.get());
    }

    @Test
    public void testNonWinningHandEmpty() {
        // empty hand should return false
        player.hasWinningHand();
        assertFalse(gameWon.get());
    }

    @Test
    public void testNonWinningHand() {
        // check that hasWinningHand() does not incorrectly deem a hand of 4 to win
        for (int i = 0; i < 4; i++) {
            player.drawCard(new Card(i));
        }
        player.hasWinningHand();
        assertFalse(gameWon.get());
    }

    @Test
    public void testChooseDiscardCard() throws NoSuchMethodException, InvocationTargetException, IllegalAccessException {

        //check that player number n correctly chooses card with value n to keep after 3 discards
        player.drawCard(new Card(1));
        player.drawCard(new Card(2));
        player.drawCard(new Card(3));
        player.drawCard(new Card(4));
        // Use reflection to call private method

        Method chooseDiscardCardMethod = Player.class.getDeclaredMethod("chooseDiscardCard");
        chooseDiscardCardMethod.setAccessible(true);
        for (int i = 0; i < 3; i++) {
            Card chosenCard = (Card) chooseDiscardCardMethod.invoke(player);
            assertNotNull(chosenCard);
            player.discardCard(chosenCard);
        }
        // player 1 should be left with exactly 1 card with value 1
        assertEquals(1, player.getHand().getFirst().getValue(),player.getHand().size());
    }

    @Test
    public void testStopPlaying() throws IllegalAccessException, NoSuchFieldException {
        // tests that a player is correctly alive and not alive according to stopPlaying()
        // Use reflection to check the 'alive' status
        Field alive = Player.class.getDeclaredField("alive");
        alive.setAccessible(true);
        assertTrue(alive.getBoolean(player));

        player.stopPlaying();
        assertFalse(alive.getBoolean(player));

    }

    @Test
    public void testOutputGeneration() throws IOException, InterruptedException {
        // Test to see that output files are being correctly created
        // Prepare test deck with predetermined cards
        drawDeck.addCard(new Card(2));
        drawDeck.addCard(new Card(3));
        drawDeck.addCard(new Card(4));
        drawDeck.addCard(new Card(5));

        player = new Player(drawDeck, discardDeck, 1, gameWon, winner);

        // Run the game a bit

        Thread playerThread = new Thread(player);
        playerThread.start();
        Thread.sleep(100);

        // Stop player
        player.stopPlaying();
        playerThread.join();

        // Verify output file was generated
        File outputFile = new File("player1_output.txt");
        assertTrue(outputFile.exists());

        // Verify that the file contains text
        List<String> lines = Files.readAllLines(outputFile.toPath());
        assertFalse(lines.isEmpty());
        outputFile.delete();
    }

    @After
    public void cleanUpTest(){
        player = null;
        drawDeck = null;
        discardDeck = null;
        gameWon = null;
    }


}

