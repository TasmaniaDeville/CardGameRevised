package TestSystem;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import src.Card;
import src.Deck;

import static org.junit.Assert.assertEquals;

public class DeckTest {
    private Deck deck;

    @Before
    public void setUpTest(){
        deck = new Deck(1);
    }

    @Test
    public void testAddAndDrawCard() {
        // check that a card can be added then drawn from a deck
        Card card = new Card(5);
        deck.addCard(card);
        Card drawn = deck.drawCard();
        assertEquals(card, drawn);
    }

    @Test
    public void testGetCurrentDeck() {
        // test that getCurrentDeck returns correct list
        Card card1 = new Card(5);
        Card card2 = new Card(6);
        deck.addCard(card1);
        deck.addCard(card2);

        var currentDeck = deck.getCurrentDeck();
        assertEquals(2, currentDeck.size());
        assertEquals(card1, currentDeck.get(0));
        assertEquals(card2, currentDeck.get(1));
    }

    @Test
    public void testGetDeckNumber() {
        assertEquals(1, deck.getDeckNumber());
    }

    @Test
    public void testAddCardOrder() {
        // test that add functions are adding cards to correct sides of the deck
        Card card1 = new Card(1);
        Card card2 = new Card(2);
        Card card3 = new Card(3);
        // This combination should be ordered 2, 1, 3 for the test to pass
        deck.addCard(card1);
        deck.addCardToTop(card2);
        deck.addCard(card3);
        assertEquals(card2.getValue(),deck.drawCard().getValue());
        assertEquals(card1.getValue(),deck.drawCard().getValue());
        assertEquals(card3.getValue(),deck.drawCard().getValue());
    }

    @After
    public void cleanUpTest() {
        deck = null;
    }
}