cardsTest Suite

-- Overview --
This test suite is designed to run the unit tests for the classes in the `cards.jar` file. The tests are written using JUnit 4.13.1.

## Requirements ##
- JDK 8 or higher
- hamcrest-core-1.3 (included)
- JUnit 4.13.1 JAR file (included)
- cards.jar (included)

-- Running the Tests --
1. Extract the contents of cardsTest.zip
2. Open a terminal or command prompt.
3. Navigate to the directory where you extracted cardsTest.zip, should simply be called cardsTest
4. if on windows, copy below and run in the terminal 

java -cp ".;junit-4.13.1.jar;cards.jar;hamcrest-core-1.3.jar" org.junit.runner.JUnitCore TestSystem.AllTests

if on Linux/MacOS then run

java -cp ".:junit-4.13.1.jar:cards.jar:hamcrest-core-1.3.jar" org.junit.runner.JUnitCore TestSystem.AllTests

!! Disclaimer, we were not able to test on Linux/MacOS so please use the windows command if able !!

5. The terminal should show the results of the tests out of 22